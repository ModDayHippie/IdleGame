# IdleGame
 IdleGame is created using python 3.8
 Python is needed to run this program on your computer. head on over to https://www.python.org/downloads/ to grab the latest version
 aswell in order to have this program workon your computer you need to install the needed moduals with the command shell
 To install go to "start" then search "Command Prompt"
 after type in "pip install replit"
 let the command shell run and install the needed modual
 after run the "gui.py" script
